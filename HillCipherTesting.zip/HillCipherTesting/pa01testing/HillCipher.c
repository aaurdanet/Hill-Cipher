/*============================================================================
| Encrypting a plaintext file using the Hill cipher
|
| Author: Antonio Urdaneta
| Language: c, c++, Java, go, python
|
| To Compile: javac pa01.java
| gcc -o pa01 pa01.c
| g++ -o pa01 pa01.cpp
| go build pa01.go
|
| To Execute: java -> java pa01 kX.txt pX.txt
| or c++ -> ./pa01 kX.txt pX.txt
| or c -> ./pa01 kX.txt pX.txt
| or go -> ./pa01 kX.txt pX.txt
| or python -> python3 pa01.py kX.txt pX.txt
| where kX.txt is the keytext file
| and pX.txt is plaintext file
| Note:
| All input files are simple 8 bit ASCII input
| All execute commands above have been tested on Eustis
+===========================================================================*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define SIZE 9// matrix size for cypher multiplication
#define BufferSize 10000
#define rows 80
int main(int argc, char* argv[]) {
	// Declare and initialize variables
	FILE* fPtr, * keytxt;
	int totalumb, alpha, pad = 0;
	char Buffer[BufferSize];
	int cipherM[SIZE][1], mess[BufferSize], encrypt[SIZE][SIZE];
	int i, k, j;
	int dn = 0;
	int character = 0;
	int count = 0;
	int dtotal = 0;
	int dsum = 0;
	//input key
	keytxt = fopen(argv[1], "r");
	if (keytxt == NULL) {
		printf("Error openning file!\n");//key file open error check
		return 0;
	}
	//input file
	fPtr = fopen(argv[2], "r");
	if (fPtr == NULL) {
		printf("Error openning file!\n");// file open error check
		return 0;
	}
	// read key file
	fscanf(keytxt, "%d", &totalumb);
	while (!feof(keytxt)) {
		for (i = 0; i < totalumb;i++) {
			for (j = 0; j < totalumb;j++) {
				fscanf(keytxt,"%d ",&encrypt[i][j]);// inserting key in encrypt double array
			}
		}
	}
	// read file
	do
	{
		alpha = fgetc(fPtr);
		//padding
		if (feof(fPtr)) {
			if (character % totalumb != 0) {
				pad = (totalumb - ((character % totalumb)));
				for (i = character; i < (character + pad); ++i) {
					Buffer[i] = 120;
				}
				break;
			}
			else
				break;
		}
		if (isalpha(alpha)) {
			if (isupper(alpha)) {
				alpha = tolower(alpha);//lowercase input plain text
				Buffer[character] = alpha;
				character++;
			}
			else if (!isspace(alpha)) {
				Buffer[character] = alpha;
				character++;
			}
		}
		else
			continue;
	} while (1);
	// Print key matrix
	printf("\n");
	printf("The Key Matrix is:\n");
	printf("\n");
	for (i = 0; i < totalumb; i++) {
		for (j = 0; j < totalumb; j++) {
			printf("%d ", encrypt[i][j]);
		}
		printf("\n");
	}
	//print newline
	printf("\n");
	// Print plaintext
	printf("Plaintext:\n");
	for (i = 0; i < (character + pad); i++) {
		if (i % 80 == 0)
			printf("\n");
		printf("%c", Buffer[i]);
	}
	//print newline
	printf("\n");
	//Matrix multiplication
	while (count < (character + pad)) {
		for (i = 0; i < totalumb; i++) {
			cipherM[i][0] = Buffer[dn] % 97;
			dn++;
		}
		for (j = 0; j < totalumb; j++) {
			for (k = 0; k < totalumb; k++) {
				dtotal = cipherM[k][0] * encrypt[j][k];
				dsum += dtotal;
			}
			dsum %= 26;
			mess[count] = dsum + 97;
			count++;
			dsum = 0;
		}
	}
	printf("The CipherText is:\n");
	for (i = 0; i < (character + pad); i++) {
		if (i % 80 == 0)// print characters in lines of 80 characters
			printf("\n");
		printf("%c", mess[i]);
	}
	printf("\n");
	fclose(fPtr);
	fclose(keytxt);
	system("pause");
	return 0;
}

